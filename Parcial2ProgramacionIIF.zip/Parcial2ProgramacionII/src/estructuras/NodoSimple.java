package estructuras;

import elemento.Container;

public class NodoSimple<T extends Comparable<T>> {

    private NodoSimple<T> siguiente;
    private T dato;

    public NodoSimple(T dato) {
        this.siguiente = null;
        this.dato = dato;
    }

    public NodoSimple<T> getSiguiente() {
        return siguiente;
    }

    public void setSiguiente(NodoSimple<T> siguiente) {
        this.siguiente = siguiente;
    }

    public T getDato() {
        return dato;
    }

    public void setDato(T dato) {
        this.dato = dato;
    }

}
