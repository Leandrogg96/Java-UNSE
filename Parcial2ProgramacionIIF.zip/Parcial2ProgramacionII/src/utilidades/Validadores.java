package utilidades;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class Validadores {

    public static int leerInt() {
        Scanner entra = new Scanner(System.in);
        while (true) {
            try {
                String input = entra.nextLine();
                return Integer.parseInt(input.trim());
            } catch (NumberFormatException e) {
                System.out.println("No es un numero entero. Por favor, pruebe otra vez!");
            }
        }
    }
    public static int leerInt09() {
        Scanner entra = new Scanner(System.in);
        while (true) {
            try {
                String input = entra.nextLine();
                return Integer.parseInt(input.trim());
            } catch (NumberFormatException e) {
                System.out.println("No es un numero entero. Por favor, pruebe otra vez!");
            }
        }
    }

    public static char leerCaracter() {
        while (true) {
            try {
                return (char) leerDato().charAt(0);
            } catch (NumberFormatException e) {
                System.out.print("ERROR! Intente nuevamente: ");
            }
        }
    }

    public static String leerDato() {
        String dato = "";
        InputStreamReader isr = new InputStreamReader(System.in);
        BufferedReader flujoE = new BufferedReader(isr);

        try {
            dato = flujoE.readLine();
        } catch (IOException e) {
            System.err.println("Error " + e.getMessage());
        }

        return dato;
    }


}

