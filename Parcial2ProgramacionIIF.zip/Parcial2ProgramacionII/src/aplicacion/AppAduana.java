package aplicacion;

import estructuras.Pila;
import utilidades.Validadores;

import static utilidades.Validadores.leerInt;

public class AppAduana {
    public static void main(String[] args) {
        AppAduana appAduana1 = new AppAduana();
        Pila pila1 = new Pila();


        appAduana1.menuPrincipal();

    }

    public void menuPrincipal() {

        int op;
        do {
            System.out.println("\n");
            System.out.println("------- DEPOSITO ADUANERO -------");
            System.out.println("1. Agregar container.");
            System.out.println("2. Retirar container");
            System.out.println("3. Control del deposito de containers.");
            System.out.println("4. Mostrar contenido del deposito.");
            System.out.println("0. Salir");
            System.out.print("Ingrese opcion: ");
            op = Validadores.leerInt();
            System.out.println("");
            switch (op) {
                case 1:
                    System.out.println("Ingresaste: 'Agregar container'.");
                    agregarContainer();
                    break;
                case 2:
                    System.out.println("Ingresaste: 'Retirar container'.");
                    retirarContainer();
                    break;
                case 3:
                    System.out.println("Mostrando informe...");
                    mostrarInforme();
                    break;
                case 4:
                    System.out.println("Mostrando contenido del deposito...");
                    mostrarDeposito();
                case 0:
                    System.out.println("Saliendo del programa...");
                    break  ;
            }
        } while (op != 0);
    }
    public void agregarContainer() {

    }
    public void retirarContainer() {

    }

    public void mostrarInforme() {

    }

    public void mostrarDeposito() {

    }


}