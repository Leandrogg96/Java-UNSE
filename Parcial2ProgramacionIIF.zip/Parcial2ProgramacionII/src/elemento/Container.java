package elemento;

import utilidades.Fecha;

import java.util.Date;
import java.util.Scanner;

import static utilidades.Validadores.leerCaracter;
import static utilidades.Validadores.leerInt;

public class Container {
    private int clave;
    private String cod;
    private int buque;
    private Date fechaA;
    private String despach;

    public Container() {
        leerConte();
    }

    public void leerConte() {
        Scanner input = new Scanner(System.in);

        System.out.println("Ingresa el codigo del contenedor: ");
        this.cod = validarCodigo();

        System.out.println("Ingresa el numero de buque: ");
        this.buque = leerInt();

        System.out.println("Ingresa la fecha de arribo: ");
        this.fechaA = new Date();

        System.out.println("Ingresa el nombre del despachante: ");
        this.despach = input.nextLine();
    }

    public String validarCodigo() {
        String codigo = "";
        String claveAux = "";


        System.out.println("Ingresa una letra: ");
        codigo = validarCaracter();

        System.out.println("Vas a cargar un numero de tres cifras: ");
        String temp = validarNum3();

        codigo += temp;
        claveAux = valorNumericoLetra(codigo) + temp;
        this.clave = Integer.parseInt(claveAux);
        return codigo;
    }


    public String validarCaracter() {
        char auxC = '0';
        while (auxC != 'F' && auxC != 'M' && auxC != 'V' && auxC != 'C') {
            System.out.println("-F: frigorificos\n -C: canerias\n -M: maquinarias\n -V: vestimenta.");
            auxC = leerCaracter();
        }
        String auxS = String.valueOf(auxC);
        return auxS;
    }

    public String valorNumericoLetra(String x) {
        if (x == "F" && x == "f") {
            return "70";
        } else if (x == "c" && x == "C") {
            return "67";
        } else if (x == "m" && x == "M") {
            return "77";
        } else {
            return "86";
        }
    }
    public String validarNum3() {
        String auxS = "";
        int auxI1 = 11;
        int auxI2 = 11;
        int auxI3 = 11;
        do {
            System.out.println("Ingresa el primer numero: (entre 0 y 9)");
            auxI1 = leerInt();
        } while (auxI1 < 10 && auxI1 >= 0);

        do {
            System.out.println("Ingresa el segundo numero: (entre 0 y 9)");
            auxI2 = leerInt();
        } while (auxI2 < 10 && auxI2 >= 0);

        do {
            System.out.println("Ingresa el tercer numero: (entre 0 y 9)");
            auxI3 = leerInt();
        } while (auxI3 < 10 && auxI3 >= 0);

        auxS = auxI1 + String.valueOf(auxI2) + auxI3;

        return auxS;
    }

    public int getClave () {
        return clave;
    }

    public void setClave ( int clave){
        this.clave = clave;
    }

    public String getCod () {
        return cod;
    }

    public void setCod (String cod){
        this.cod = cod;
    }

    public int getBuque () {
        return buque;
    }

    public void setBuque ( int buque){
        this.buque = buque;
    }

/*
public Date getFechaA() {
    return fechaA;
}

public void setFechaA(Date fechaA) {
    this.fechaA = fechaA;
}
*/
    public String getDespach () {
        return despach;
    }

    public void setDespach (String despach){
        this.despach = despach;
    }

}
