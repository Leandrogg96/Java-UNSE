
package listaordenada;

//import java.util.*;

import java.util.Scanner;
import Fecha.fecha;
public class Main {

    Scanner ingreso = new Scanner(System.in);

    ListaOrdenada miLista;

    public Main() {
        miLista = new ListaOrdenada();
    }

    public void generar() {
        int elem = -1;
        while (elem != 0) {
            prt("Ingrese id vuelo (0 p/cancelar): ");
            elem = ingreso.nextInt();
            if (elem != 0) {
                ingreso.nextLine();
                System.out.println("Ingrese destino");
                String des=ingreso.nextLine();
                System.out.println("Ingrese hora");
                String hs=ingreso.nextLine();
                System.out.println("Ingrese fecha: ");
                //String fe=ingreso.nextLine();
                System.out.print("dia: ");
                int dd=ingreso.nextInt();
                System.out.print("mes: ");
                int mm=ingreso.nextInt();
                System.out.print("Año:  ");
                int aa=ingreso.nextInt();
                fecha fe=new fecha(dd,mm,aa);
                
                Vuelo v= new Vuelo(elem,des,fe,hs);
                miLista.insertar(v);
            }
        }
    }

    public void borrar() {
        int elem = -1;
        while (elem != 0) {
            prt("Ingrese id vuelo (0 p/cancelar): ");
            elem = ingreso.nextInt();
            if (elem != 0) {
                Nodo x = miLista.eliminar(elem);
            }
        }
    }

    public void imprimir() {
        Nodo p = miLista.inicio();
        System.out.println("Id   Destino  Fecha   Hora");
        while (p != null) {
            Vuelo v=p.getDato();
            //prt(p.getDato() + "");
            System.out.print(v.getId()+"    ");
            System.out.print(v.getDestino()+"    ");
            
            System.out.print(v.getFecha().getDia()+"/");
            System.out.print(v.getFecha().getMes()+"/");
            System.out.print(v.getFecha().getAño()+"  ");
            System.out.println(v.getHora()+"    ");
            p = p.getPs();
        }
    }

    public boolean verificar() {
        if (miLista.listaVacia()) {
            prt("Lista vacía!");
            return false;
        }
        return true;
    }

    public void menu() {
        int opcion = 9;
        do {
            switch (opcion) {
                case 1:
                    generar();
                    break;
                case 2:
                    if (verificar()) {
                        imprimir();
                    }
                    break;
                case 3:
                    if (verificar()) {
                        borrar();
                    }
                    break;

            }
            mostrarOpciones();
            opcion = ingreso.nextInt();
            prt("--------->");

        } while (opcion != 0);
    }

    public void mostrarOpciones() {
        prt("Manejo de listas simples enlazadas");
        prt("1- Cargar");
        prt("2- Imprimir");
        prt("3- Borrar");
        prt("0- Salir");
        prt("--------->");

    }

    public void prt(String s) {
        System.out.println(s);
    }

    public static void main(String[] args) {

        Main miListaApp = new Main();
        miListaApp.menu();

    }

}
