package listaordenada;


public class Nodo {

    private Vuelo dato;
    private Nodo ps;

    public Nodo(Vuelo elem) {
        dato = elem;
        ps = null;
    }

    /**
     * @return el dato
     */
    public Vuelo getDato() {
        return dato;
    }

    /**
     * @param dato el dato a establecer
     */
    public void setDato(Vuelo dato) {
        this.dato = dato;
    }

    /**
     * @return el ps
     */
    public Nodo getPs() {
        return ps;
    }

    /**
     * @param ps el ps a establecer
     */
    public void setPs(Nodo ps) {
        this.ps = ps;
    }

}
