
package listaordenada;

import Fecha.fecha;


public class Vuelo {
    private int id;
    private String Destino;
    private fecha fecha;
    private String hora;

    public Vuelo(int id, String Destino, fecha fecha, String hora) {
        this.id = id;
        this.Destino = Destino;
        this.fecha = fecha;
        this.hora = hora;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDestino() {
        return Destino;
    }

    public void setDestino(String Destino) {
        this.Destino = Destino;
    }

    public fecha getFecha() {
        return fecha;
    }

    public void setFecha(fecha fecha) {
        this.fecha = fecha;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }
    
    
}
